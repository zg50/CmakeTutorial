#!/bin/bash

rm *~
