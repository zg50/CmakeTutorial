//MathFunctions.h内容
#include <iostream>
#include <math.h>

double mysqrt(double a) ;
