//TutorialConfig.h.in（需要新建）文件里的内容
// the configured options and settings for Tutorial
#define Tutorial_VERSION_MAJOR 1
#define Tutorial_VERSION_MINOR 0

#define USE_MYMATH
#define HAVE_LOG
#define HAVE_EXP
